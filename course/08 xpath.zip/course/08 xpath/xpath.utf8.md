---
title: "Web Data Collection with R"
author: "Peter Meißner / 2016-02-29 --  2016-03-04 / ECPR WSMT"
header-includes:
  - \definecolor{links}{HTML}{800080}
  - \hypersetup{colorlinks,linkcolor=,urlcolor=links}
output:
  beamer_presentation:
    fonttheme: structurebold
    keep_tex: yes
    toc: yes
  slidy_presentation: default
subtitle: Xpath
keep_tex: yes
---


# HTML/XML tree structure again
## HTML/XML tree structure, nodes and attributes
http://www.r-datacollection.com/materials/html/fortunes.html
![image](tree.png)


# Running Example 

## running example

```r
require(rvest)
require(stringr)
```



```r
url <- 
"http://pmeissner.com/downloads/fortunes.html"
fname <- basename(url)

if(!file.exists(fname)){
  download.file(url, fname)
}

html <- read_html(fname)
```

## running example


```r
xml2::html_structure(html)
```

```
## <html>
##   {text}
##   <head>
##     {text}
##     <title>
##       {text}
##     {text}
##     <style>
##       {cdata}
##     {text}
##   {text}
##   <body>
##     {text}
##     <div#R_Inventor [lang, date]>
##       {text}
##       <h1.pink>
##         {text}
##       {text}
##       <p>
##         {text}
##         <i>
##           {text}
##         {text}
##       {text}
##       <p>
##         {text}
##         <b.pink>
##           {text}
##         {text}
##       {text}
##     {text}
##     <div [lang, date]>
##       {text}
##       <h1.pink>
##         {text}
##       {text}
##       <p>
##         {text}
##         <i>
##           {text}
##         <br>
##         {text}
##         <emph>
##           {text}
##         {text}
##       {text}
##       <p>
##         {text}
##         <b.pink>
##           {text}
##         {text}
##         <a [href]>
##           {text}
##         {text}
##       {text}
##     {text}
##     <address>
##       {text}
##       <a [href]>
##         {text}
##         <i>
##           {text}
##         {text}
##       {text}
##     {text}
##   {text}
```


# How XPath works ...


## XPath? What is it all about? 
- XPath is a query language for XML (Extensible Markup Language) documents 
- XML examples are: [XML, HTML, SVG, GML, KML, EPUB, RSS, Office Open XML, OpenDocument](https://en.wikipedia.org/wiki/List_of_XML_markup_languages)
- in XPath on selects nodes describing the paths that lead to that path




## How XPath Works ... 
- builds on 
    - **hierarchy** (select parent, child, sibling, ... node)
    - **node names** (select node by name)
    - **node values** (select node by value)
    - **attribute name and value** (select node on attribute value)
    - **further functions** (select depending on more complex derivates of the above)
        - e.g. name, string_length, contains, count, position, ... 
    - **operators**
        - e.g. `|`, `+`, `-`, `=`, `!=`, `<=`, `or`, `and`, ...
- allows to extract
    - node values 
    - attribute values
- ... from single nodes and node sets


## explicit path

```r
x="/html/body/div[2]/h1"
html_nodes(html, xpath=x)
```

```
## {xml_nodeset (1)}
## [1] <h1 class="pink">Rolf Turner</h1>
```

## path anywhere in hierarchy

```r
html_nodes(html, xpath="//h1")
```

```
## {xml_nodeset (2)}
## [1] <h1 class="pink">Robert Gentleman</h1>
## [2] <h1 class="pink">Rolf Turner</h1>
```

## path anywhere in hierarchy / attribute 

```r
html_nodes(html, xpath="//a/@href")
```

```
## {xml_nodeset (2)}
## [1]  href="https://stat.ethz.ch/mailman/listinfo/r-help"
## [2]  href="www.r-datacollectionbook.com"
```

## path anywhere in hierarchy / function

```r
html_nodes(html, xpath="//p/i/text()")
```

```
## {xml_nodeset (2)}
## [1] 'What we have is nice, but we need something very different'
## [2] 'R is wonderful, but it cannot work magic'
```

## path anywhere in hierarchy / indexing

```r
html_nodes(html, xpath="//div[1]/p/i")
```

```
## {xml_nodeset (1)}
## [1] <i>'What we have is nice, but we need something very different'</i>
```

## path anywhere in hierarchy / indexing

```r
html_nodes(html, xpath="//div")
```

```
## {xml_nodeset (2)}
## [1] <div id="R_Inventor" lang="english" date="June/2003">\n\t\t\t<h1 cla ...
## [2] <div lang="english" date="October/2011">\n\t\t\t<h1 class="pink">Rol ...
```

```r
html_nodes(html, xpath="//div[1]")
```

```
## {xml_nodeset (1)}
## [1] <div id="R_Inventor" lang="english" date="June/2003">\n\t\t\t<h1 cla ...
```

```r
html_nodes(html, xpath="//div[1]/p/i/text()")
```

```
## {xml_nodeset (1)}
## [1] 'What we have is nice, but we need something very different'
```

## node / attribute contains/is equal ... 

```r
html_nodes(html, xpath="//div[@date='October/2011']")
```

```
## {xml_nodeset (1)}
## [1] <div lang="english" date="October/2011">\n\t\t\t<h1 class="pink">Rol ...
```

```r
html_nodes(html, xpath="//div[contains(@date, 'October/2011')]")
```

```
## {xml_nodeset (1)}
## [1] <div lang="english" date="October/2011">\n\t\t\t<h1 class="pink">Rol ...
```

```r
html_nodes(html, xpath="//div[contains(.//a/@href, 'https')]")
```

```
## {xml_nodeset (1)}
## [1] <div lang="english" date="October/2011">\n\t\t\t<h1 class="pink">Rol ...
```

## node / attribute contains/is equal ... 

```r
html_nodes(html, xpath="//a[contains(@href, 'https')]")
```

```
## {xml_nodeset (1)}
## [1] <a href="https://stat.ethz.ch/mailman/listinfo/r-help">R-help</a>
```

```r
html_nodes(html, xpath="//a[contains(., 'homepage')]")
```

```
## {xml_nodeset (1)}
## [1] <a href="www.r-datacollectionbook.com">\n\t\t\t\t<i>The book homepag ...
```


## node parent 

```r
html_nodes(html, xpath="//a")
```

```
## {xml_nodeset (2)}
## [1] <a href="https://stat.ethz.ch/mailman/listinfo/r-help">R-help</a>
## [2] <a href="www.r-datacollectionbook.com">\n\t\t\t\t<i>The book homepag ...
```

```r
html_nodes(html, xpath="//a/..")
```

```
## {xml_nodeset (2)}
## [1] <p>\n\t\t\t\t<b class="pink">Source: </b>\n\t\t\t\t<a href="https:// ...
## [2] <address>\n\t\t\t<a href="www.r-datacollectionbook.com">\n\t\t\t\t<i ...
```

## all nodes everywhere

```r
html_nodes(html, xpath="//*")
```

```
## {xml_nodeset (23)}
##  [1] <html> \n\t<head>\n\t\t<title>Collected R wisdoms</title>\n\t\t<sty ...
##  [2] <head>\n\t\t<title>Collected R wisdoms</title>\n\t\t<style><![CDATA ...
##  [3] <title>Collected R wisdoms</title>
##  [4] <style><![CDATA[\n\t\t\t.pink    {color:pink;}\n\t\t]]></style>
##  [5] <body>\n\t\t<div id="R_Inventor" lang="english" date="June/2003">\n ...
##  [6] <div id="R_Inventor" lang="english" date="June/2003">\n\t\t\t<h1 cl ...
##  [7] <h1 class="pink">Robert Gentleman</h1>
##  [8] <p>\n\t\t\t\t<i>'What we have is nice, but we need something very d ...
##  [9] <i>'What we have is nice, but we need something very different'</i>
## [10] <p>\n\t\t\t\t<b class="pink">Source: </b>Statistical Computing 2003 ...
## [11] <b class="pink">Source: </b>
## [12] <div lang="english" date="October/2011">\n\t\t\t<h1 class="pink">Ro ...
## [13] <h1 class="pink">Rolf Turner</h1>
## [14] <p>\n\t\t\t\t<i>'R is wonderful, but it cannot work magic'</i><br/> ...
## [15] <i>'R is wonderful, but it cannot work magic'</i>
## [16] <br/>
## [17] <emph>answering a request for automatic generation of 'data from a  ...
## [18] <p>\n\t\t\t\t<b class="pink">Source: </b>\n\t\t\t\t<a href="https:/ ...
## [19] <b class="pink">Source: </b>
## [20] <a href="https://stat.ethz.ch/mailman/listinfo/r-help">R-help</a>
## ...
```


## all nodes' text everywhere

```r
html_nodes(html, xpath="//*/text()")
```

```
## {xml_nodeset (43)}
##  [1]  \n\t
##  [2] \n\t\t
##  [3] Collected R wisdoms
##  [4] \n\t\t
##  [5] <![CDATA[\n\t\t\t.pink    {color:pink;}\n\t\t]]>
##  [6] \n\t
##  [7] \n\t
##  [8] \n\t\t
##  [9] \n\t\t\t
## [10] Robert Gentleman
## [11] \n\t\t\t
## [12] \n\t\t\t\t
## [13] 'What we have is nice, but we need something very different'
## [14] \n\t\t\t
## [15] \n\t\t\t
## [16] \n\t\t\t\t
## [17] Source: 
## [18] Statistical Computing 2003, Reisensburg\n\t\t\t
## [19] \n\t\t
## [20] \n\t\t
## ...
```


## that node or the other 

```r
html_nodes(html, xpath="//i | //b")
```

```
## {xml_nodeset (5)}
## [1] <i>'What we have is nice, but we need something very different'</i>
## [2] <b class="pink">Source: </b>
## [3] <i>'R is wonderful, but it cannot work magic'</i>
## [4] <b class="pink">Source: </b>
## [5] <i>The book homepage</i>
```

## using axis :: parent

```r
html_nodes(html, xpath="//a/..")
```

```
## {xml_nodeset (2)}
## [1] <p>\n\t\t\t\t<b class="pink">Source: </b>\n\t\t\t\t<a href="https:// ...
## [2] <address>\n\t\t\t<a href="www.r-datacollectionbook.com">\n\t\t\t\t<i ...
```

```r
html_nodes(html, xpath="//a/parent::*")
```

```
## {xml_nodeset (2)}
## [1] <p>\n\t\t\t\t<b class="pink">Source: </b>\n\t\t\t\t<a href="https:// ...
## [2] <address>\n\t\t\t<a href="www.r-datacollectionbook.com">\n\t\t\t\t<i ...
```

```r
html_nodes(html, xpath="//a/parent::p")
```

```
## {xml_nodeset (1)}
## [1] <p>\n\t\t\t\t<b class="pink">Source: </b>\n\t\t\t\t<a href="https:// ...
```

## using axis :: child

```r
html_nodes(html, xpath="//p/i")
```

```
## {xml_nodeset (2)}
## [1] <i>'What we have is nice, but we need something very different'</i>
## [2] <i>'R is wonderful, but it cannot work magic'</i>
```

```r
html_nodes(html, xpath="//p/child::*")
```

```
## {xml_nodeset (7)}
## [1] <i>'What we have is nice, but we need something very different'</i>
## [2] <b class="pink">Source: </b>
## [3] <i>'R is wonderful, but it cannot work magic'</i>
## [4] <br/>
## [5] <emph>answering a request for automatic generation of 'data from a k ...
## [6] <b class="pink">Source: </b>
## [7] <a href="https://stat.ethz.ch/mailman/listinfo/r-help">R-help</a>
```

```r
html_nodes(html, xpath="//p/child::i")
```

```
## {xml_nodeset (2)}
## [1] <i>'What we have is nice, but we need something very different'</i>
## [2] <i>'R is wonderful, but it cannot work magic'</i>
```

## using axis :: ancestor

```r
html_nodes(html, xpath="//b/ancestor::*")
```

```
## {xml_nodeset (6)}
## [1] <html> \n\t<head>\n\t\t<title>Collected R wisdoms</title>\n\t\t<styl ...
## [2] <body>\n\t\t<div id="R_Inventor" lang="english" date="June/2003">\n\ ...
## [3] <div id="R_Inventor" lang="english" date="June/2003">\n\t\t\t<h1 cla ...
## [4] <p>\n\t\t\t\t<b class="pink">Source: </b>Statistical Computing 2003, ...
## [5] <div lang="english" date="October/2011">\n\t\t\t<h1 class="pink">Rol ...
## [6] <p>\n\t\t\t\t<b class="pink">Source: </b>\n\t\t\t\t<a href="https:// ...
```

```r
html_nodes(html, xpath="//b/ancestor::*/text()")
```

```
## {xml_nodeset (20)}
##  [1]  \n\t
##  [2] \n\t
##  [3] \n\t\t
##  [4] \n\t\t\t
##  [5] \n\t\t\t
##  [6] \n\t\t\t
##  [7] \n\t\t\t\t
##  [8] Statistical Computing 2003, Reisensburg\n\t\t\t
##  [9] \n\t\t
## [10] \n\t\t
## [11] \n\t\t\t
## [12] \n\t\t\t
## [13] \n\t\t\t
## [14] \n\t\t\t\t
## [15] \n\t\t\t\t
## [16] \n\t\t\t
## [17] \n\t\t
## [18] \n\t\t
## [19] \n\t
## [20]  \n
```

## using axis :: descendant

```r
html_nodes(html, xpath="//p/descendant::*")
```

```
## {xml_nodeset (7)}
## [1] <i>'What we have is nice, but we need something very different'</i>
## [2] <b class="pink">Source: </b>
## [3] <i>'R is wonderful, but it cannot work magic'</i>
## [4] <br/>
## [5] <emph>answering a request for automatic generation of 'data from a k ...
## [6] <b class="pink">Source: </b>
## [7] <a href="https://stat.ethz.ch/mailman/listinfo/r-help">R-help</a>
```

```r
html_nodes(html, xpath="//p/descendant::*/text()")
```

```
## {xml_nodeset (6)}
## [1] 'What we have is nice, but we need something very different'
## [2] Source: 
## [3] 'R is wonderful, but it cannot work magic'
## [4] answering a request for automatic generation of 'data from a known m ...
## [5] Source: 
## [6] R-help
```

## using axis :: following-sibling / preceding-sibling

```r
html_nodes(html, xpath="//b/..")
```

```
## {xml_nodeset (2)}
## [1] <p>\n\t\t\t\t<b class="pink">Source: </b>Statistical Computing 2003, ...
## [2] <p>\n\t\t\t\t<b class="pink">Source: </b>\n\t\t\t\t<a href="https:// ...
```

```r
html_nodes(html, xpath="//b/following-sibling::*")
```

```
## {xml_nodeset (1)}
## [1] <a href="https://stat.ethz.ch/mailman/listinfo/r-help">R-help</a>
```


# How CSS-Selectors Work ... 

## How CSS-Selectors Work ... 
- CSS-Selectors were designed to apply Styles to HTML elements
- While XPath is build around the idea of hierarchy and tree-structure first and foremost meaning that paths lead to data, with CSS-S selection is more set-like. 
- CSS-S is used and written for Web-Designers so it might be less-powerful-complete-systematic than XPath but it is also less intimidating and easier to write
- selection on class and id attributes is super easy
    - **name** (select nodes by name)
    - **id** (select node id attribute)
    - **node values** (select node by value)
    - **attribute name and value** (select node on attribute value)
    - **hierarchy** (select depending on the position in path)

## selecting nodes by name

```r
html_nodes(html, "p")
```

```
## {xml_nodeset (4)}
## [1] <p>\n\t\t\t\t<i>'What we have is nice, but we need something very di ...
## [2] <p>\n\t\t\t\t<b class="pink">Source: </b>Statistical Computing 2003, ...
## [3] <p>\n\t\t\t\t<i>'R is wonderful, but it cannot work magic'</i><br/>\ ...
## [4] <p>\n\t\t\t\t<b class="pink">Source: </b>\n\t\t\t\t<a href="https:// ...
```

```r
html_nodes(html, "b, i")
```

```
## {xml_nodeset (5)}
## [1] <i>'What we have is nice, but we need something very different'</i>
## [2] <b class="pink">Source: </b>
## [3] <i>'R is wonderful, but it cannot work magic'</i>
## [4] <b class="pink">Source: </b>
## [5] <i>The book homepage</i>
```

## selecting nodes by class

```r
html_nodes(html, ".pink")
```

```
## {xml_nodeset (4)}
## [1] <h1 class="pink">Robert Gentleman</h1>
## [2] <b class="pink">Source: </b>
## [3] <h1 class="pink">Rolf Turner</h1>
## [4] <b class="pink">Source: </b>
```

## selecting nodes by id

```r
html_nodes(html, css = "#R_Inventor")
```

```
## {xml_nodeset (1)}
## [1] <div id="R_Inventor" lang="english" date="June/2003">\n\t\t\t<h1 cla ...
```

```r
html_nodes(html, css = "[id='R_Inventor']")
```

```
## {xml_nodeset (1)}
## [1] <div id="R_Inventor" lang="english" date="June/2003">\n\t\t\t<h1 cla ...
```

## selecting nodes by attribute

```r
html_nodes(html, css = "[lang]")
```

```
## {xml_nodeset (2)}
## [1] <div id="R_Inventor" lang="english" date="June/2003">\n\t\t\t<h1 cla ...
## [2] <div lang="english" date="October/2011">\n\t\t\t<h1 class="pink">Rol ...
```

```r
html_nodes(html, css = "[href]")
```

```
## {xml_nodeset (2)}
## [1] <a href="https://stat.ethz.ch/mailman/listinfo/r-help">R-help</a>
## [2] <a href="www.r-datacollectionbook.com">\n\t\t\t\t<i>The book homepag ...
```

## selecting nodes by attribute value

```r
html_nodes(html, css = "[id=R_Inventor]") # equal
```

```
## {xml_nodeset (1)}
## [1] <div id="R_Inventor" lang="english" date="June/2003">\n\t\t\t<h1 cla ...
```

```r
html_nodes(html, css = "[id^=R]")         # starts 
```

```
## {xml_nodeset (1)}
## [1] <div id="R_Inventor" lang="english" date="June/2003">\n\t\t\t<h1 cla ...
```

```r
html_nodes(html, css = "[id$=r]")         # ends
```

```
## {xml_nodeset (1)}
## [1] <div id="R_Inventor" lang="english" date="June/2003">\n\t\t\t<h1 cla ...
```

```r
html_nodes(html, css = "[id*=ven]")       # conatains
```

```
## {xml_nodeset (1)}
## [1] <div id="R_Inventor" lang="english" date="June/2003">\n\t\t\t<h1 cla ...
```

## selecting nodes by path characteristics : decendant

```r
html_nodes(html, css = "i")
```

```
## {xml_nodeset (3)}
## [1] <i>'What we have is nice, but we need something very different'</i>
## [2] <i>'R is wonderful, but it cannot work magic'</i>
## [3] <i>The book homepage</i>
```

```r
html_nodes(html, css = "a i")
```

```
## {xml_nodeset (1)}
## [1] <i>The book homepage</i>
```

## selecting nodes by path characteristics :parent

```r
html_nodes(html, css = "p > i")
```

```
## {xml_nodeset (2)}
## [1] <i>'What we have is nice, but we need something very different'</i>
## [2] <i>'R is wonderful, but it cannot work magic'</i>
```

```r
html_nodes(html, css = "a > i")
```

```
## {xml_nodeset (1)}
## [1] <i>The book homepage</i>
```

## selecting nodes by path characteristics : first of type

```r
html_nodes(html, css = "p:first-of-type")
```

```
## {xml_nodeset (2)}
## [1] <p>\n\t\t\t\t<i>'What we have is nice, but we need something very di ...
## [2] <p>\n\t\t\t\t<i>'R is wonderful, but it cannot work magic'</i><br/>\ ...
```


## selecting nodes by path characteristics : nth child of parent

```r
html_nodes(html, css = "a:nth-child(1)")
```

```
## {xml_nodeset (1)}
## [1] <a href="www.r-datacollectionbook.com">\n\t\t\t\t<i>The book homepag ...
```

```r
html_nodes(html, css = "a:nth-child(2)")
```

```
## {xml_nodeset (1)}
## [1] <a href="https://stat.ethz.ch/mailman/listinfo/r-help">R-help</a>
```

## selecting nodes by path characteristics : nth child of parent

```r
html_nodes(html, css = "a:nth-last-child(1)")
```

```
## {xml_nodeset (2)}
## [1] <a href="https://stat.ethz.ch/mailman/listinfo/r-help">R-help</a>
## [2] <a href="www.r-datacollectionbook.com">\n\t\t\t\t<i>The book homepag ...
```

```r
html_nodes(html, css = "a:nth-last-child(2)")
```

```
## {xml_nodeset (0)}
```


## selecting nodes by path characteristics : nth child of parent

```r
html_nodes(html, css = "p:nth-of-type(1)")
```

```
## {xml_nodeset (2)}
## [1] <p>\n\t\t\t\t<i>'What we have is nice, but we need something very di ...
## [2] <p>\n\t\t\t\t<i>'R is wonderful, but it cannot work magic'</i><br/>\ ...
```



# R-Packages and Functions
## rvest and XML

**rvest** (httr + xml2 + selectr)

  - scraping centered package (download and extraction)
  - HTML / XML
  - XPath / CSS-S
  - very handy and slick
  - we use this 
    
**XML** (xml)

  - XML centered package (parsing and extraction)
  - XPath
  - much more powerful in terms of parsing (also SAX for LARGE documents)
  - goes back to 1999 (according to README; you know just after the internet became a thing)
  - two good sources cover that one: Nolan & Temple-Lang (2013): *XML and Web Technologies for Data Sciences with R*; Munzert et al (2014): *Automated Data Collection with R*

  
## rvest's (important) XML handling functions

function           | description
------------------ | ------------
`read_html()`      | parse HTML (file); all others based on
`html_structure()` | shows the structure of an HTML (doc)
`as_list()`        | transform parsed XML / HTML to list (doc)
`html_attr()`      | get specific attribute value (node)
`html_attrs()`     | get all attributes (node)
`html_text()`      | get node's and children's text (node)
`html_children()`  | get children of node (doc, node)
`xml_path()`       | gives back the explicit path to nodes (node)
`xml_length()`     | number of children (node)
`html_name()`      | name of nodes (node)
`xml_parent()`     | gives back parent of node (node)
`xml_parents()`    | gives back all ancestors of node (node)
`xml_siblings()`   | gives back nodes with the same parent (node)
`xml_type()`       | gives back type (node, doc)

doc: parsed document; node: node set or node; file: un-parsed XML document



# Selector Gadget and Developer Tools to the Rescue

## Selector Gadget and Developer Tools to the Rescue
- building Xpath (CSS-S) expressions is an art (practice hard and be creative)
- ... and easily and quickly becomes mind buggling and complicated ...
- ... there are however some tools that might help lessen the burden:
    - selectorgadget : http://selectorgadget.com/
    - developer tools : 
        - Chrome: https://developer.chrome.com/devtools 
        - Firefox: https://developer.mozilla.org/de/docs/Tools
        - Opera: http://www.opera.com/dragonfly/
        - Safari: https://developer.apple.com/safari/tools/
        - Edge: https://dev.windows.com/en-us/microsoft-edge/platform/documentation/f12-devtools-guide/
        






















