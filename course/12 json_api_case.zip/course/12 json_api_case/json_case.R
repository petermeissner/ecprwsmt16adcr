## ---- message=FALSE------------------------------------------------------
library(rvest)
library(jsonlite)
library(lubridate)
library(dplyr)

## ---- cache=TRUE---------------------------------------------------------
url  <- "http://stats.grok.se/json/en/latest90/Influenza"
json <- html_text(read_html(url)) 
json

## ---- cache=TRUE, echo=FALSE, message=FALSE------------------------------
require(stringr)
cat(str_c(unlist(str_split(json, ",")),",\n")[1:13],"\n...")

## ---- eval=FALSE---------------------------------------------------------
## data  <- fromJSON(json)
## date  <- as.Date(names(data$daily_views))
## views <- unlist(data$daily_views)
## 
## plot( date, views,
##       ylim = c(0, 3000),
##       type = "h",
##       col  = "#F54B1A90",
##       lwd=3,
##       main="Influenca Page Views on Wikipedia (en)")
## 
## lines(lowess(views ~ date), col = "#1B346C90", lwd=5)

## ---- echo=FALSE---------------------------------------------------------
data  <- fromJSON(json)
date  <- as.Date(names(data$daily_views))
views <- unlist(data$daily_views)

plot( date, views,  
      type = "h", 
      col  = "#F54B1A90",
      lwd=3, 
      main="Influenca Page Views on Wikipedia (en)")

lines(lowess(views ~ date), col = "#1B346C90", lwd=5)

## ---- cache=TRUE---------------------------------------------------------
url_pt1  <- "http://stats.grok.se/json/en/"
url_pt2  <- 
  paste0(
    rep(2014:2015, each=12),
    str_pad(1:12, width=2, side="left", "0")
  )
url_pt3  <- "/Influenza"
URL <- paste0(url_pt1, url_pt2, url_pt3)

## ------------------------------------------------------------------------
# downloadig the data
JSON <- list()
for( i in seq_along(URL) ){
  fname <- basename(dirname(URL[i]))
  if( !file.exists(fname) ){
    download.file(URL[i], fname )
    Sys.sleep(1)
  }
  JSON[i] <- readLines(fname, warn = FALSE)
}

## ------------------------------------------------------------------------
# parsing the JSON
JSON_parsed <- lapply(JSON, fromJSON)

json <- JSON_parsed[[1]]

date <- 
  json$daily_views %>% 
  names() %>% 
  ymd()

views <- 
  json$daily_views %>% 
  unlist()

views[1:3]
date[1:3]

## ------------------------------------------------------------------------
# putting it in a function
page_views_to_df <- function(json){
  date  <- json$daily_views %>% names() %>% ymd()
  views <- json$daily_views %>% unlist()
  df <- data.frame(date, views)[!is.na(date),]
  rownames(df) <- NULL
  return(df)
}

## ------------------------------------------------------------------------
influenza15 <- 
  JSON_parsed %>% 
  lapply(page_views_to_df) %>% 
  do.call(rbind, .) 

## ---- eval=FALSE---------------------------------------------------------
## 
## plot( influenza15$date, influenza15$views,
##       type = "h",
##       col  = "#F54B1A90",
##       lwd=1,
##       main="Influenca Page Views on Wikipedia (en)")
## 
## lowess(influenza15$views ~ influenza15$date, f=0.08) %>%
##   lines(col = "#1B346C90", lwd=5)

## ---- echo=FALSE---------------------------------------------------------

plot( influenza15$date, influenza15$views,  
      type = "h", 
      col  = "#F54B1A90",
      lwd=1, 
      main="Influenca Page Views on Wikipedia (en)")

lowess(influenza15$views ~ influenza15$date, f=0.08) %>% 
  lines(col = "#1B346C90", lwd=5)

